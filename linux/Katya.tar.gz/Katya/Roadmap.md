
# Roadmap

Here is a tentative roadmap for the Katya project:

- **Q4 2024**: Finalize the mobile and web versions.
- **Q1 2025**: Introduce cloud integration for user data synchronization.
- **Q2 2025**: Improve accessibility and performance.
- **Q3 2025**: Launch version 2.0 with advanced new features.
